<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;

class SupplierAuthControllerImage extends Controller
{
    /**
     * Handle supplier profile image upload and store under public/uploads/suppliers
     */
    public function updateProfileImage(Request $request)
    {
        $request->validate([
            'profile_image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $supplier = $request->user();

        $destDir = public_path('uploads/suppliers');
        if (! File::exists($destDir)) {
            File::makeDirectory($destDir, 0755, true);
        }

        // Delete existing profile image if not default
        if ($supplier->profile_image && $supplier->profile_image !== 'uploads/default.png') {
            $existing = public_path($supplier->profile_image);
            if (File::exists($existing)) {
                File::delete($existing);
            }
        }

        $file = $request->file('profile_image');
        $filename = Str::uuid().'.'.$file->getClientOriginalExtension();
        $file->move($destDir, $filename);

        $supplier->profile_image = 'uploads/suppliers/'.$filename;
        $supplier->save();

        return response()->json([
            'message' => 'Profile image updated successfully',
            'user' => $supplier,
            'profile_image_url' => URL::to($supplier->profile_image),
        ]);
    }
}
