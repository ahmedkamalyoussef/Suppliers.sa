<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Supplier\UpdateSupplierProfileRequest;
use App\Http\Resources\Supplier\SupplierResource;
use App\Models\Otp;
use App\Models\Supplier;
use App\Models\SupplierProfile;
use App\Models\SystemSettings;
use App\Notifications\OtpNotification;
use App\Services\SupplierProfileService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Laravel\Sanctum\PersonalAccessToken;
use App\Http\Requests\Auth\UpdateSupplierPreferencesRequest;


class SupplierAuthController extends Controller
{
    public function register(Request $request)
    {
        $accountName = $request->input('account_name') ?? $request->input('accountName') ?? $request->input('business_name') ?? $request->input('businessName') ?? $request->input('name');
        if (!empty($accountName)) {
            $request->merge([
                'account_name' => $accountName,
                'business_name' => $accountName,
                'name' => $accountName,
            ]);
        }

        if (! $request->has('password_confirmation') && $request->filled('passwordConfirmation')) {
            $request->merge(['password_confirmation' => $request->input('passwordConfirmation')]);
        }

        $validator = Validator::make($request->all(), [
            'business_name' => ['required', 'string', 'max:255'],
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique('suppliers', 'email')->where(function ($query) {
                    return $query->whereNotNull('email_verified_at');
                }),
                Rule::unique('admins', 'email'),
            ],
            'phone' => ['required', 'string', 'max:20'],
            'password' => [
                'required',
                'string',
                'confirmed',
                Password::min(8)
                    ->mixedCase()
                    ->symbols(),
            ],
            'password_confirmation' => ['required', 'string', 'min:8'],
            'accept_policies' => ['required', 'boolean', 'accepted'],
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        // Check if supplier exists but is not verified
        $existingSupplier = Supplier::where('email', $request->email)
            ->whereNull('email_verified_at')
            ->first();

        if ($existingSupplier) {
            // Update existing supplier data
            $existingSupplier->update([
                'name' => $request->business_name,
                'password' => Hash::make($request->password),
                'phone' => $request->phone,
                'email_verified_at' => null, // Keep as null for new verification
                'status' => 'pending', // Reset to pending
            ]);

            // Update profile
            if ($existingSupplier->profile) {
                $existingSupplier->profile->update([
                    'business_name' => $request->business_name,
                    'main_phone' => $request->phone,
                    'contact_email' => $request->email,
                ]);
                $existingSupplier->profile->slug = $this->generateUniqueSupplierSlug($request->business_name, $existingSupplier->profile->id);
                $existingSupplier->profile->save();
            }

            $supplier = $existingSupplier;
            $message = 'Registration successful. Please verify your email to activate your account.';
            
            $response = [
                'message' => $message,
                'supplier' => (new SupplierResource($supplier))->toArray($request),
            ];

            return response()->json($response, 201);
        }

        // Check if auto-approve businesses is enabled
        $autoApprove = false;
        $systemSettings = SystemSettings::first();
        if ($systemSettings && $systemSettings->auto_approve_businesses) {
            $autoApprove = true;
        }

        $supplier = Supplier::create([
            'name' => $request->business_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
            'email_verified_at' => null,
            'profile_image' => 'uploads/default.png',
            'plan' => 'Basic',
            'status' => $autoApprove ? 'active' : 'pending',
            'role' => 'supplier', // Add default role
        ]);

        $profile = SupplierProfile::create([
            'supplier_id' => $supplier->id,
            'business_name' => $request->business_name,
            'main_phone' => $request->phone,
            'contact_email' => $request->email,
            'slug' => null,
            'latitude' => $this->generateRiyadhRandomLatitude(),
            'longitude' => $this->generateRiyadhRandomLongitude(),
        ]);

        $profile->slug = $this->generateUniqueSupplierSlug($profile->business_name, $profile->id);
        $profile->save();

        $supplier->load('profile');

        $message = $autoApprove 
            ? 'Registration successful. Your business has been automatically approved and is now active.'
            : 'Registration successful. Please verify your email and await admin approval.';

        $response = [
            'message' => $message,
            'supplier' => (new SupplierResource($supplier))->toArray($request),
        ];

        return response()->json($response, 201);
    }

    public function login(Request $request)
    {
        $request->validate(['email' => ['required', 'email'], 'password' => ['required']]);

        $supplier = Supplier::where('email', $request->email)->first();

        if (! $supplier || ! Hash::check($request->password, $supplier->password)) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        if (! $supplier->email_verified_at) {
            return response()->json(['message' => 'Email not verified', 'email_verified' => false], 403);
        }

        $token = $supplier->createToken('auth-token')->plainTextToken;
        $supplier->forceFill(['last_seen_at' => now()])->save();
        $supplier->load('profile');

        $supplierArray = (new SupplierResource($supplier))->toArray($request);
        $supplierArray['role'] = 'supplier'; // Add role to the response
        
        return response()->json([
            'message' => 'Login successful',
            'supplier' => $supplierArray,
            'accessToken' => $token,
            'tokenType' => 'Bearer',
            'role' => 'supplier', // Also add role at the root level for easier access
        ]);
    }

    public function logout(Request $request)
    {
        $bearer = $request->bearerToken();
        if ($bearer) {
            $pat = PersonalAccessToken::findToken($bearer);
            if ($pat) {
                $pat->delete();
            }
        }

        return response()->json(['message' => 'Logged out successfully']);
    }

    public function sendOtp(Request $request)
    {
        $request->validate(['email' => ['required', 'email']]);

        $supplier = Supplier::where('email', $request->email)->first();
        if (! $supplier) {
            return response()->json(['message' => 'Email not found'], 404);
        }

        $otp = Otp::generateForSupplier($supplier->id, $supplier->email);
        $supplier->notify(new OtpNotification($otp->otp, 10, 'verification'));

        $response = ['message' => 'OTP sent successfully'];

        if (app()->environment('local', 'testing')) {
            $response['debugOtp'] = $otp->otp;
        }

        return response()->json($response);
    }

    public function verifyOtp(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email', 'exists:suppliers,email'],
            'otp' => ['required', 'string', 'size:4'],
        ]);

        $supplier = Supplier::where('email', $request->email)->first();
        $otp = Otp::where('supplier_id', $supplier->id)
            ->where('otp', $request->otp)
            ->where('expires_at', '>', now())
            ->first();

        if (! $otp || ! $otp->isValid()) {
            return response()->json(['message' => 'Invalid or expired OTP'], 400);
        }

        $supplier->email_verified_at = now();
        $supplier->status = 'active';
        $supplier->save();

        $otp->delete();

        $token = $supplier->createToken('auth-token')->plainTextToken;
        $supplier->load('profile');

        $supplierArray = (new SupplierResource($supplier))->toArray($request);
        $supplierArray['role'] = 'supplier';
        
        return response()->json([
            'message' => 'Email verified successfully',
            'supplier' => $supplierArray,
            'accessToken' => $token,
            'tokenType' => 'Bearer',
            'role' => 'supplier',
        ]);
    }

    public function updateProfile(Request $request)
    {
        return $this->updateProfilePartial($request);
    }

    public function updateProfilePartial(UpdateSupplierProfileRequest $request)
    {
        $supplier = $request->user();

        if (! ($supplier instanceof Supplier)) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        // Validation & normalization are handled by UpdateSupplierProfileRequest
        
        // Handle supplier's name (for authentication/display)
        if ($request->filled('name')) {
            $supplier->name = $request->name;
        }

        if ($request->filled('contactPhone')) {
            $supplier->phone = $request->contactPhone;
        }

        // Handle contact email in profile instead of supplier's main email
        if ($request->filled('contactEmail')) {
            $profileData['contact_email'] = $request->contactEmail;
        }

        $supplier->save();

        $profile = $supplier->profile ?: SupplierProfile::create(['supplier_id' => $supplier->id]);

        $profileData = [];

        $service = new SupplierProfileService;
        $profileData = $service->buildProfileDataFromRequest($request, $profile);

        if (! $profile->slug && isset($profileData['business_name'])) {
            $profileData['slug'] = $this->generateUniqueSupplierSlug($profileData['business_name'], $profile->id);
        }

        if (! empty($profileData)) {
            $profile->update($profileData);
        }

        // Create branches inline if provided
        $service->createInlineBranches($supplier, $request);

        // Handle supplier document upload (no metadata)
        $service->handleDocumentUpload($supplier, $request);

        $supplier->load('profile', 'branches');

        return response()->json([
            'message' => 'Profile updated successfully',
            'supplier' => (new SupplierResource($supplier))->toArray($request),
        ]);
    }

    public function getProfile(Request $request)
    {
        $supplier = $request->user();

        if (! ($supplier instanceof Supplier)) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $supplier->loadMissing(['profile', 'branches', 'approvedRatings']);

        $profile = $supplier->profile;
        $ratingAverage = $supplier->approvedRatings()->avg('score');
        $ratingCount = $supplier->approvedRatings()->count();

        $ratingDistribution = $supplier->approvedRatings()
            ->selectRaw('score, COUNT(*) as count')
            ->groupBy('score')
            ->pluck('count', 'score')
            ->toArray();

        $response = [
            'id' => $supplier->id,
            'businessName' => $profile?->business_name ?? $supplier->name,
            'businessType' => $profile?->business_type ?? 'Supplier',
            'categories' => $profile?->business_categories ?? [],
            'services' => $profile?->services_offered ?? [],
            'description' => $profile?->description,
            'website' => $profile?->website,
            'address' => $profile?->business_address,
            'serviceDistance' => $profile?->service_distance,
            'contactPhone' => $profile?->main_phone ?? $supplier->phone,
            'contactEmail' => $profile?->contact_email ?? $supplier->email,
            'profileImage' => $this->mediaUrl($supplier->profile_image),
            'status' => $supplier->status,
            'verificationStatus' => $supplier->status === 'active' ? 'verified' : ($supplier->status === 'pending' ? 'pending_verification' : 'suspended'),
            'plan' => $supplier->plan ?? 'Basic',
            'rating' => [
                'average' => $ratingAverage ? round((float) $ratingAverage, 2) : 0,
                'total' => $ratingCount,
            ],
            'workingHours' => $profile?->working_hours ?? $this->defaultWorkingHours(),
            'productKeywords' => $profile?->keywords ?? [],
            'targetCustomers' => $profile?->target_market ?? [],
            'additionalPhones' => $profile?->additional_phones ?? [],
            'createdAt' => optional($supplier->created_at)->toIso8601String(),
            'updatedAt' => optional($supplier->updated_at)->toIso8601String(),
        ];

        return response()->json($response);
    }

    public function updateProfileImage(Request $request)
    {
        $request->validate(['profile_image' => 'required|image']);

        $supplier = $request->user();
        $destDir = public_path('uploads/suppliers');

        if (! File::exists($destDir)) {
            File::makeDirectory($destDir, 0755, true);
        }

        if ($supplier->profile_image && File::exists(public_path($supplier->profile_image))) {
            File::delete(public_path($supplier->profile_image));
        }

        $file = $request->file('profile_image');
        $filename = Str::uuid().'.'.$file->getClientOriginalExtension();
        $file->move($destDir, $filename);

        $supplier->profile_image = 'uploads/suppliers/'.$filename;
        $supplier->save();

        $supplier->load('profile');

        return response()->json(['message' => 'Profile image updated successfully', 'supplier' => (new SupplierResource($supplier))->toArray($request)]);
    }

    protected function mediaUrl(?string $path): ?string
    {
        if (! $path) {
            return null;
        }

        if (Str::startsWith($path, ['http://', 'https://'])) {
            return $path;
        }

        return url($path);
    }

    private function defaultWorkingHours(): array
    {
        $days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        $default = [];

        foreach ($days as $day) {
            $default[$day] = [
                'open' => $day === 'sunday' ? '10:00' : '08:00',
                'close' => $day === 'sunday' ? '16:00' : '18:00',
                'closed' => $day === 'sunday',
            ];
        }

        return $default;
    }

    private function generateUniqueSupplierSlug(string $name, ?int $profileId = null): string
    {
        $base = Str::slug($name);
        if (! $base) {
            $base = 'supplier';
        }

        $slug = $base;
        $counter = 1;
        while (
            SupplierProfile::where('slug', $slug)
                ->when($profileId, fn ($query) => $query->where('id', '!=', $profileId))
                ->exists()
        ) {
            $slug = $base.'-'.$counter++;
        }

        return $slug;
    }

    /**
     * Get supplier preferences
     */
    public function getPreferences(Request $request)
    {
        $supplier = $request->user();
        
        if (! ($supplier instanceof Supplier)) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        // Load profile to get business name
        $supplier->load('profile');

        return response()->json([
            'supplierName' => $supplier->name,
            'businessName' => $supplier->profile?->business_name,
            'email' => $supplier->email,
            'phone' => $supplier->phone,
            'preferences' => [
                // Notification Preferences
                'emailNotifications' => (bool) $supplier->email_notifications,
                'smsNotifications' => (bool) $supplier->sms_notifications,
                'newInquiriesNotifications' => (bool) $supplier->new_inquiries_notifications,
                'profileViewsNotifications' => (bool) $supplier->profile_views_notifications,
                'weeklyReports' => (bool) $supplier->weekly_reports,
                'marketingEmails' => (bool) $supplier->marketing_emails,
                
                // Security Preferences
                'profileVisibility' => $supplier->profile_visibility ?? 'public',
                'showEmailPublicly' => (bool) $supplier->show_email_publicly,
                'showPhonePublicly' => (bool) $supplier->show_phone_publicly,
                'allowDirectContact' => (bool) $supplier->allow_direct_contact,
                'allowSearchEngineIndexing' => (bool) $supplier->allow_search_engine_indexing,
            ]
        ]);
    }

    /**
     * Update supplier preferences
     */
    public function updatePreferences(UpdateSupplierPreferencesRequest $request)
    {
        $supplier = $request->user();
        
        if (! ($supplier instanceof Supplier)) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        // Update profile fields
        if ($request->filled('name')) {
            $supplier->name = $request->name;
        }
        
        if ($request->filled('email')) {
            $supplier->email = $request->email;
        }
        
        if ($request->filled('phone')) {
            $supplier->phone = $request->phone;
        }
        
        // Update business name in profile
        if ($request->filled('businessName')) {
            $profile = $supplier->profile ?: new SupplierProfile(['supplier_id' => $supplier->id]);
            $profile->business_name = $request->businessName;
            $profile->save();
        }

        // Update Notification Preferences
        $supplier->email_notifications = $request->input('emailNotifications', $supplier->email_notifications);
        $supplier->sms_notifications = $request->input('smsNotifications', $supplier->sms_notifications);
        $supplier->new_inquiries_notifications = $request->input('newInquiriesNotifications', $supplier->new_inquiries_notifications);
        $supplier->profile_views_notifications = $request->input('profileViewsNotifications', $supplier->profile_views_notifications);
        $supplier->weekly_reports = $request->input('weeklyReports', $supplier->weekly_reports);
        $supplier->marketing_emails = $request->input('marketingEmails', $supplier->marketing_emails);

        // Update Security Preferences
        $supplier->profile_visibility = $request->input('profileVisibility', $supplier->profile_visibility ?? 'public');
        $supplier->show_email_publicly = $request->input('showEmailPublicly', $supplier->show_email_publicly);
        $supplier->show_phone_publicly = $request->input('showPhonePublicly', $supplier->show_phone_publicly);
        $supplier->allow_direct_contact = $request->input('allowDirectContact', $supplier->allow_direct_contact);
        $supplier->allow_search_engine_indexing = $request->input('allowSearchEngineIndexing', $supplier->allow_search_engine_indexing);
        
        // Save all changes
        $supplier->save();
        
        // Return updated profile and preferences
        return response()->json([
            'message' => 'Profile and preferences updated successfully',
            'data' => [
                'name' => $supplier->name,
                'email' => $supplier->email,
                'phone' => $supplier->phone,
                'businessName' => $supplier->profile ? $supplier->profile->business_name : null,
                'emailNotifications' => (bool) $supplier->email_notifications,
                'smsNotifications' => (bool) $supplier->sms_notifications,
                'newInquiriesNotifications' => (bool) $supplier->new_inquiries_notifications,
                'profileViewsNotifications' => (bool) $supplier->profile_views_notifications,
                'weeklyReports' => (bool) $supplier->weekly_reports,
                'marketingEmails' => (bool) $supplier->marketing_emails,
                'profileVisibility' => $supplier->profile_visibility,
                'showEmailPublicly' => (bool) $supplier->show_email_publicly,
                'showPhonePublicly' => (bool) $supplier->show_phone_publicly,
                'allowDirectContact' => (bool) $supplier->allow_direct_contact,
                'allowSearchEngineIndexing' => (bool) $supplier->allow_search_engine_indexing
            ]
        ]);
    }

    public function deleteAccount(Request $request)
    {
        $supplier = $request->user();
        
        if (! ($supplier instanceof Supplier)) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        try {
            // Start database transaction
            \DB::beginTransaction();

            // Delete profile image if exists
            if ($supplier->profile_image) {
                $imagePath = public_path(str_replace(url('/'), '', $supplier->profile_image));
                if (file_exists($imagePath)) {
                    @unlink($imagePath);
                }
            }

            // Delete product images with their files
            foreach ($supplier->productImages()->get() as $image) {
                $path = public_path(str_replace(url('/'), '', $image->image_url));
                if (file_exists($path)) {
                    @unlink($path);
                }
                $image->delete();
            }

            // Delete products
            foreach ($supplier->products()->get() as $product) {
                // Delete product images
                foreach ($product->images()->get() as $prodImage) {
                    $path = public_path(str_replace(url('/'), '', $prodImage->image_url));
                    if (file_exists($path)) {
                        @unlink($path);
                    }
                    $prodImage->delete();
                }
                $product->delete();
            }

            // Delete services
            $supplier->services()->delete();

            // Delete certifications
            $supplier->certifications()->delete();

            // Delete documents
            foreach ($supplier->documents()->get() as $doc) {
                if ($doc->file_path) {
                    $path = public_path(str_replace(url('/'), '', $doc->file_path));
                    if (file_exists($path)) {
                        @unlink($path);
                    }
                }
                $doc->delete();
            }

            // Delete profile if exists
            if ($supplier->profile) {
                $supplier->profile->delete();
            }

            // Delete branches
            $supplier->branches()->delete();

            // Delete inquiries
            $supplier->inquiries()->delete();
            $supplier->receivedSupplierInquiries()->delete();
            $supplier->sentSupplierInquiries()->delete();

            // Delete ratings
            $supplier->ratingsGiven()->delete();
            $supplier->ratingsReceived()->delete();

            // Delete reports
            $supplier->reportsReceived()->delete();
            $supplier->reportsSubmitted()->delete();

            // Delete all tokens (logout from all devices)
            $supplier->tokens()->delete();

            // Delete the supplier
            $supplier->delete();

            \DB::commit();

            return response()->json(['message' => 'Account deleted successfully']);
        } catch (\Exception $e) {
            \DB::rollBack();
            \Log::error('Delete account failed: ' . $e->getMessage());
            return response()->json([
                'message' => 'Failed to delete account',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get supplier location coordinates
     */
    public function getLocation(Request $request)
    {
        $supplier = $request->user();
        
        if (! ($supplier instanceof Supplier)) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        // Load the supplier's profile to get location data
        $supplier->load('profile');
        
        if (! $supplier->profile) {
            return response()->json([
                'message' => 'Profile not found',
                'latitude' => null,
                'longitude' => null
            ], 404);
        }

        return response()->json([
            'latitude' => $supplier->profile->latitude,
            'longitude' => $supplier->profile->longitude,
            'address' => $supplier->profile->business_address
        ]);
    }

    /**
     * Generate random latitude within Riyadh bounds
     * Riyadh latitude range: approximately 24.7136° to 24.8136°
     */
    protected function generateRiyadhRandomLatitude(): float
    {
        return mt_rand(24713600, 24813600) / 1000000;
    }

    /**
     * Generate random longitude within Riyadh bounds
     * Riyadh longitude range: approximately 46.6753° to 46.7753°
     */
    protected function generateRiyadhRandomLongitude(): float
    {
        return mt_rand(46675300, 46775300) / 1000000;
    }
}
