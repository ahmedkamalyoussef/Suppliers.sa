<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SupplierResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $accountName = $this->profile?->business_name ?? $this->name;

        return [
            'id' => $this->id,
            'name' => $accountName,
            'account_name' => $accountName,
            'accountName' => $accountName,
            'business_name' => $accountName,
            'businessName' => $accountName,
            'email' => $this->email,
            'phone' => $this->phone,
            'profile_image' => $this->profile_image ? asset($this->profile_image) : null, // Supplier's profile image
            'status' => $this->status,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
            'profile' => $this->whenLoaded('profile', function () use ($accountName) {
                return [
                    'account_name' => $this->profile->business_name ?? $accountName,
                    'accountName' => $this->profile->business_name ?? $accountName,
                    'business_name' => $this->profile->business_name ?? $accountName,
                    'businessName' => $this->profile->business_name ?? $accountName,
                    'business_type' => $this->profile->business_type ?? null,
                    'description' => $this->profile->description ?? null,
                    'website' => $this->profile->website ?? null,
                    'main_phone' => $this->profile->main_phone ?? null,
                    'business_address' => $this->profile->business_address ?? null,
                    'latitude' => $this->profile->latitude ?? null,
                    'longitude' => $this->profile->longitude ?? null,
                    'category' => $this->profile->category ?? null,
                    'business_image' => $this->profile->business_image ? asset($this->profile->business_image) : null,
                ];
            }),
        ];
    }
}
