<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/kemo/Development/Work/Freelance/supplier/Suppliers.sa/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>