<?php echo e($slot); ?>

<?php /**PATH /home/kemo/Development/Work/Freelance/supplier/Suppliers.sa/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>